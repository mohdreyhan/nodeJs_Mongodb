const navbarMenu = [
    {
        id : 1,
        name : "Projects",
        path: "/projects"
    },
    {
        id : 1,
        name : "Add Task",
        path: "/addtasks"
    },
    {
        id : 1,
        name : "Manage Task",
        path: "/managetasks"
    }
]

export default navbarMenu