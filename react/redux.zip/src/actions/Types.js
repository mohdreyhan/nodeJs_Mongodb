export const SIGNUP_INPUTS = "SIGNUP_INPUTS";

export const SIGNUPSUCCESS_ERROR = "SIGNUPSUCCESS_ERROR";

export const LOGIN_INPUTS = "LOGIN_INPUTS";

export const LOGIN_SUCCESS = "LOGIN_SUCCESS";

export const LOGOUT_SUCCESS = "LOGOUT_SUCCESS";

export const TASKADDED_SUCCESS = "TASKADDED_SUCCESS";

export const TASK_DETAILS = "TASK_DETAILS";

export const USERS_DATA = "USERS_DATA";

export const ASSIGN_ACTION = "ASSIGN_ACTION";

export const ASSIGNEMP_INPUTS = "ASSIGNEMP_INPUTS";

export const UPDATETASK_INPUTS = "UPDATETASK_INPUTS";

export const SHEET_DATA = "SHEET_DATA";

export const START_STARTED = "START_STARTED";

export const ALL_STATUSES = "ALL_STATUSES";

export const EMP_ROLES = "EMP_ROLES";

export const UPDATE_USER_ROLE = "UPDATE_USER_ROLE";